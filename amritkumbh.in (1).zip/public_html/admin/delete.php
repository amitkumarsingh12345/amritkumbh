<?php
 include "connection.php";

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "DELETE FROM room WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        echo "Record deleted successfully";
          header("Location: room.php");
exit;
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
