<?php
 include "connection.php";

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "DELETE FROM customer WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        echo "Record deleted successfully";
          header("Location: index.php");
exit;
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
