<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <title>Amrit Kumbh</title>

    <style>
      .product-card {
        margin-bottom: 20px;
      }
      .product-image {
        width: 100%;
        height: 200px;
        object-fit: cover;
        border-radius: 8px;
      }
      .card-title {
        font-size: 1.25rem;
        font-weight: bold;
      }
      .card-text {
        font-size: 1rem;
        color: #555;
      }
      .table th, .table td {
        text-align: center;
        vertical-align: middle;
      }
      .table-responsive {
        overflow-x: auto;
      }
    </style>
  </head>
  <body>
    <!-- Header Start -->
    <?php include_once 'header.php'; ?>
    <!-- Header End -->

    <div class="container mt-5 ">
        <h2 class="text-center mb-4">Message List</h2>
        
        <!-- Room Table for Large Screens -->
        <div class="table-responsive d-none d-md-block">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Sr.No</th>
                <th>Name</th>
                <th>Email</th>
                <th>Subject</th>
                <th>Message</th>
                <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    include 'connection.php';

$sql = "SELECT * FROM messages";
$result = $conn->query($sql);
$i = 0;

                    while ($row = $result->fetch_assoc()) { 
                      $i = $i+1;
                    ?>
                        <tr>
                            <td><?php echo $i; ?></td>
                            <td><?php echo $row['name']; ?></td>
                            <td><?php echo $row['email']; ?></td>
                            <td><?php echo $row['subject']; ?></td>
                            <td><?php echo $row['message']; ?></td>
                           <td>
                                <a href="deletemsg.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm">Delete</a>
                           </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>

        <!-- Room Cards for Small & Medium Screens -->
        <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 d-inline-block d-md-none">
            <?php 
            
              include 'connection.php';

$sql = "SELECT * FROM messages";
$result = $conn->query($sql);
$i = 0;
            while ($row = $result->fetch_assoc()) {
                $i = $i + 1;
            ?>
                <div class="col mb-4">
                    <div class="card h-100 shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $i; ?></h5>
                            <h5 class="card-title"><?php echo $row['name']; ?></h5>
                            <p class="card-text"><strong>Email:</strong> <?php echo $row['email']; ?></p>
                            <p class="card-text"><strong>Subject:</strong> <?php echo $row['subject']; ?></p>
                             <p class="card-text"><strong>Message:</strong> <?php echo $row['message']; ?></p>
                              <p class="card-text"><a href="deletemsg.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm">Delete</a></p>
                             
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz4fnFO9gybB3vsIO+PpPp4M6e9a6X/21cKH95Xg9U7T2RfwXjj3gR+Hax" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-ZvpUoO/+PpE0h7c3vc0Xj5T1f0o8LwYv6q9Pbxl1/NFfc5n8g8L5y+2xuZ2fNNh0b" crossorigin="anonymous"></script>
  </body>
</html>
