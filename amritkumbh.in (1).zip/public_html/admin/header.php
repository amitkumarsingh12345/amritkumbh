<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Amrit Kumbh</title>

    <!-- Bootstrap CSS CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    
    <style>
        /* Custom Styles */
        .navbar {
            background-color: #1E3D58;
        }

        .navbar-brand {
            font-weight: bold;
            color: #fff;
        }

        .navbar-nav .nav-link {
            color: #D0E2FF !important;
            font-weight: 500;
        }

        .navbar-nav .nav-link:hover {
            color: #F39C12 !important;
        }

        .navbar-toggler {
            border-color: #F39C12;
        }

        .navbar-toggler-icon {
            background-color: #F39C12;
        }

        /* Styling the logout button */
        #logout {
            background-color: #D9534F;
            border: none;
            color: white;
            cursor: pointer;
        }

        #logout:hover {
            background-color: #C9302C;
        }

        .form-control {
            width: 250px;
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container-fluid">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <a class="navbar-brand" href="index.php">Amrit Kumbh Dashboard</a>
            <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="/admin/index.php">Customers</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/admin/room.php">Rooms</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/admin/message.php">Messages</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link disabled" aria-disabled="true">Disabled</a>
                    </li>
                </ul>
                
                <!-- Logout Form outside the navbar items -->
                <form action="header.php" method="post" class="d-flex ms-auto">
                    <input type="submit" class="btn btn-danger" name="logout" id="logout" value="Logout">
                </form>

                <!-- Uncomment Search Form if needed -->
                <!--
                <form class="d-flex ms-3" role="search">
                    <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn btn-outline-light" type="submit">Search</button>
                </form>
                -->
            </div>
        </div>
    </nav>

    <!-- Bootstrap JS and Popper.js CDN -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz4fnFO9gybU7rM2v8M4F2u0vGoH1VtWkFdU7b6z3WnQ7W3xvH6JXo5H0p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-pzjw8f+ua7Kw1TIq0gFfDg5f2z8YbuDiBl3mJhtlJxflN6V1qq91ZtTmjwUl/0p" crossorigin="anonymous"></script>

    <?php
        if(isset($_POST['logout'])) {
            // Clear the user email cookie
            setcookie("user_email", "", time() - 3600, "/");

            // Redirect to the login page
            header("Location: ../index.php");
            exit; // Don't forget to exit after header redirect
        }
    ?>
</body>
</html>
