      <div class="container-fluid bg-dark text-light footer wow fadeIn" data-wow-delay="0.1s">
            <div class="container pb-5">
                <div class="row g-5">
                    <div class="col-md-6 col-lg-4">
                        <div class="bg-primary rounded p-4">
                            <a href="index.php">
                                <h1 class="text-white text-uppercase mb-3">Amrit Kumbh</h1>
                            </a>
                            <p class="text-white mb-0">
                                West Hotel <a class="text-dark fw-medium" href="">Amrit Kumbh</a>,
                                Experience Divine Comfort at Amrit Kumbh Hotel – Your Perfect Stay During the Sacred Festival!
                            </p>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <h6 class="section-title text-start text-primary text-uppercase mb-4">Contact</h6>
                        <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>Geaoge Town, Prayagraj, Uttar Pradesh,
                            India</p>
                        <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+91 7291049805</p>
                        <p class="mb-2"><i class="fa fa-envelope me-3"></i>amritkumbh8@gmail.com</p>
                        <div class="d-flex pt-2">
                          <a class="me-3" href="https://www.facebook.com/share/15mpkx1zr8/?mibextid=wwXIfr" target="_blank"><i class="fab fa-facebook-f"></i></a>
                                <!--<a class="me-3" href=""><i class="fab fa-twitter"></i></a>-->
                                <!--<a class="me-3" href=""><i class="fab fa-linkedin-in"></i></a>-->
                                <a class="me-3" href="https://www.instagram.com/_v_vijay_chauhan8889?igsh=cmVnNWluMnV4MTBx&utm_source=qr" target="_blank"><i class="fab fa-instagram"></i></a>
                                <!--<a class="" href=""><i class="fab fa-youtube"></i></a>-->
                        </div>
                    </div>
                    <div class="col-lg-5 col-md-12">
                        <div class="row gy-5 g-4">
                            <div class="col-md-6">
                                <h6 class="section-title text-start text-primary text-uppercase mb-4">Near</h6>
                                <a class="btn btn-link">Sangam Ghat - 1km</a>
                                <a class="btn btn-link">Shivalay - 1km</a>
                                <a class="btn btn-link">Aril Ghat - 0.5km</a>
                                <a class="btn btn-link">Someshwar Mandir Ghat - 1km</a>
                            </div>
                            <div class="col-md-6">
                                <h6 class="section-title text-start text-primary text-uppercase mb-4">Near Station</h6>
                                <a class="btn btn-link" >Chhiwaki Station - 4km</a>
                                <a class="btn btn-link" >Naini Station - 5km</a>
                                <a class="btn btn-link" >Mirgapur Hiway - 3km</a>
                                <a class="btn btn-link" >Riwa Hiway - 4km</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="copyright">
                    <div class="row">
                        <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                            &copy; <a class="border-bottom" href="#">Your Site Name</a>, All Right Reserved.
                            Designed By <a class="border-bottom" href="">Omware Infosystem Pvt Ltd</a>
                        </div>
                        <div class="col-md-6 text-center text-md-end">
                            <div class="footer-menu">
                                <a href="index.php">Home</a>
                                <a href="">Cookies</a>
                                <a href="">Help</a>
                                <a href="">FQAs</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>