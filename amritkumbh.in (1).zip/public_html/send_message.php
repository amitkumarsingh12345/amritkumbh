<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate input
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $subject = htmlspecialchars($_POST['subject']);
    $message = htmlspecialchars($_POST['message']);

    // Define email details
    $to = "amitkumarsingh1482@gmail.com"; 
    $subject_line = "Contact Form Submission: " . $subject;

    // Compose email body
    $email_body = "You have received a new message from your website contact form.\n\n";
    $email_body .= "Name: " . $name . "\n";
    $email_body .= "Email: " . $email . "\n";
    $email_body .= "Subject: " . $subject . "\n";
    $email_body .= "Message: " . $message . "\n";

    // Set email headers
    $headers = "From: " . $email . "\r\n";
    $headers .= "Reply-To: " . $email . "\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

    // Database credentials
    include 'admin/connection.php';

    // Prepare and bind statement to insert data into the database
    $stmt = $conn->prepare("INSERT INTO messages (name, email, subject, message) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $email, $subject, $message);  // Fixed the bind_param type

    // Execute the query
    if ($stmt->execute()) {
        // Send the email
        if (mail($to, $subject_line, $email_body, $headers)) {
            // Set a cookie to indicate successful submission
            setcookie("electronic", true, time() + 3600, "/");  // Expiry time added
            header("Location: contact.php?success=true");  // Redirect to contact page with success flag
            exit();
        } else {
            // If email fails, redirect with error flag
            header("Location: contact.php?error=email_failed");
            exit();
        }
    } else {
        // If database insertion fails, redirect with error flag
        header("Location: contact.php?error=db_failed");
        exit();
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}
?>
