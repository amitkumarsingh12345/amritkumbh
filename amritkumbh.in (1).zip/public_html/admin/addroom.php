<?php
include "connection.php";

// Handle form submission
if (isset($_POST['submit'])) {
    // Get form data
    $name = $_POST['name'];
    $size = $_POST['size'];
    $price = $_POST['price'];
    $gst = $_POST['gst'];
    $discount = $_POST['discount'];
    $facilities = $_POST['facilities'];

    // Handle file upload
    $profile_image = $_FILES['profile_image']['name'];
    $tmp_name = $_FILES['profile_image']['tmp_name'];
    $target_dir = "uploads/";  // Directory for file uploads
    $target_file = $target_dir . basename($profile_image);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check if the file is an image
    $check = getimagesize($tmp_name);
    if ($check !== false) {
        // Check file extension (only allow certain image types)
        if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
            echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        } else {
            // Check file size (limit to 5MB for example)
            if ($_FILES["profile_image"]["size"] > 5000000) {
                echo "Sorry, your file is too large.";
            } else {
                // Move uploaded file to target directory
                if (move_uploaded_file($tmp_name, $target_file)) {
                    // Prepare the SQL statement
                    $stmt = $conn->prepare("INSERT INTO room (name, size, price, gst, discount, facilities, profile_image) VALUES (?, ?, ?, ?, ?, ?, ?)");
                    // Use 's' for strings and 'd' for decimal values (if applicable)
                    $stmt->bind_param("sssssss", $name, $size, $price, $gst, $discount, $facilities, $target_file);

                    if ($stmt->execute()) {
                        echo "Registration successful!";
                        header("Location: room.php");
exit;
                    } else {
                        echo "Error: " . $stmt->error;
                    }

                    // Close the prepared statement
                    $stmt->close();
                } else {
                    echo "Sorry, there was an error uploading your file.";
                }
            }
        }
    } else {
        echo "The file is not an image.";
    }
}

// Close the database connection
$conn->close();
?>
