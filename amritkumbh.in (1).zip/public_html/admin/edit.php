<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Amrit Kumbh</title>
    <style>
        /* Basic Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Body Styling */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }

        /* Form Container Styling */
        .form-container {
            background-color: #fff;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 500px;
        }

        /* Header Styling */
        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
            font-size: 24px;
            font-weight: 600;
        }

        /* Label Styling */
        label {
            font-size: 14px;
            margin-bottom: 8px;
            display: block;
            color: #555;
        }

        /* Input Fields Styling */
        input[type="text"],
        input[type="email"],
        input[type="password"],
        textarea,
        input[type="file"] {
            width: 100%;
            padding: 12px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            background-color: #f9f9f9;
            transition: all 0.3s ease;
        }

        /* Input focus effect */
        input[type="text"]:focus,
        input[type="email"]:focus,
        input[type="password"]:focus,
        textarea:focus,
        input[type="file"]:focus {
            border-color: #3498db;
            outline: none;
            box-shadow: 0 0 8px rgba(52, 152, 219, 0.5);
        }

        /* Textarea Styling */
        textarea {
            resize: vertical;
            font-family: 'Arial', sans-serif;
            font-size: 16px;
        }

        /* Submit Button Styling */
        input[type="submit"] {
            width: 100%;
            padding: 14px;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        /* Submit Button Hover Effect */
        input[type="submit"]:hover {
            background-color: #2980b9;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .form-container {
                padding: 20px;
                margin: 10px;
            }

            h2 {
                font-size: 20px;
            }

            input[type="submit"] {
                font-size: 16px;
                padding: 12px;
            }

            input[type="text"],
            input[type="email"],
            input[type="password"],
            textarea,
            input[type="file"] {
                font-size: 14px;
                padding: 10px;
            }
        }
    </style>
</head>
<body>
    <?php
    include 'connection.php';

    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $result = $conn->query("SELECT * FROM room WHERE id=$id");
        $row = $result->fetch_assoc();
    }

$oldfile = $row['profile_image'];

    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
        $name = $_POST['name'];
        $size = $_POST['size'];
        $price = $_POST['price'];
        $gst = $_POST['gst'];
        $discount = $_POST['discount'];
        $facilities = $_POST['facilities'];
        $profile_image = $_FILES['profile_image']['name'];

        if ($profile_image) {
            $target_dir = "uploads/";
            $target_file = $target_dir . basename($profile_image);
            move_uploaded_file($_FILES['profile_image']['tmp_name'], $target_file);
            $profile_image = $target_file;
        } else {
            $profile_image = $row['profile_image']; 
        }

        $sql = "UPDATE room SET name='$name', size='$size', price='$price', gst='$gst', discount='$discount', facilities='$facilities', profile_image='$profile_image' WHERE id=$id";

        if ($conn->query($sql) === TRUE) {
            echo "Record updated successfully";
              header("Location: room.php");
exit;
        } else {
            echo "Error: " . $conn->error;
        }
    }
    ?>

    <div class="form-container">
        <h2>Update Room</h2>
        <form action="edit.php?id=<?php echo $id; ?>" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?php echo $row['id']; ?>" /> 

            <label for="name">Room Name:</label>
            <input type="text" name="name" id="name" value="<?php echo $row['name']; ?>" required />

            <label for="size">Size:</label>
            <input type="text" name="size" id="size" value="<?php echo $row['size']; ?>" required />

            <label for="price">Price:</label>
            <input type="text" name="price" id="price" value="<?php echo $row['price']; ?>" required />

            <label for="gst">GST:</label>
            <input type="text" name="gst" id="gst" value="<?php echo $row['gst']; ?>" required />

            <label for="discount">Discount:</label>
            <input type="text" name="discount" id="discount" value="<?php echo $row['discount']; ?>" required />

            <label for="facilities">Facilities:</label>
            <textarea name="facilities" id="facilities" required><?php echo $row['facilities']; ?></textarea>

            <label for="profile_image">Profile Image:</label>
            <input type="file" name="profile_image" id="profile_image" />

            <input type="submit" name="update" value="Update Room" />
        </form>
    </div>
</body>
</html>
