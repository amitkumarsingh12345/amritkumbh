<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <title>Amrit Kumbh</title>

    <style>
      .product-card {
        margin-bottom: 20px;
      }
      .product-image {
        width: 100%;
        height: 200px;
        object-fit: cover;
        border-radius: 8px;
      }
      .card-title {
        font-size: 1.25rem;
        font-weight: bold;
      }
      .card-text {
        font-size: 1rem;
        color: #555;
      }
      .table th, .table td {
        text-align: center;
        vertical-align: middle;
      }
      .table-responsive {
        overflow-x: auto;
      }
    </style>
  </head>
  <body>
    <!-- Header Start -->
    <?php include_once 'header.php'; ?>
    <!-- Header End -->

    <div class="container mt-5 ">
        <h2 class="text-center mb-4">Room List</h2>
        
       <a href="create.php">
            <button class="btn btn-primary mb-4">New +</button>
       </a>

        <!-- Room Table for Large Screens -->
        <div class="table-responsive d-none d-md-block">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>S.No.</th>
                        <th>Name</th>
                        <th>Size</th>
                        <th>Price</th>
                        <th>GST</th>
                        <th>Discount</th>
                        <th>Facilities</th>
                        <th>Profile Image</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    include 'connection.php';

$sql = "SELECT * FROM room";
$result = $conn->query($sql);
$i = 0;

                    while ($row = $result->fetch_assoc()) { 
                      $i = $i+1;
                    ?>
                        <tr>
                            <td><?php echo $i; ?></td>
                            <td><?php echo $row['name']; ?></td>
                            <td><?php echo $row['size']; ?></td>
                            <td><?php echo $row['price']; ?></td>
                            <td><?php echo $row['gst']; ?></td>
                            <td><?php echo $row['discount']; ?></td>
                            <td><?php echo $row['facilities']; ?></td>
                            <td><img src="<?php echo $row['profile_image']; ?>" width="50" height="50" class="img-fluid"></td>
                            <td>
                                <a href="edit.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                <a href="delete.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm">Delete</a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>

        <!-- Room Cards for Small & Medium Screens -->
        <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 d-inline-block d-md-none">
            <?php 
            
              include 'connection.php';

$sql = "SELECT * FROM room";
$result = $conn->query($sql);

            while ($row = $result->fetch_assoc()) {
            ?>
                <div class="col mb-4">
                    <div class="card h-100 shadow-sm">
                        <img src="<?php echo $row['profile_image']; ?>" class="card-img-top product-image" alt="Room Image">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $i; ?></h5>
                            <h5 class="card-title"><?php echo $row['name']; ?></h5>
                            <p class="card-text"><strong>Size:</strong> <?php echo $row['size']; ?></p>
                            <p class="card-text"><strong>Price:</strong> ₹<?php echo $row['price']; ?></p>
                            <p class="card-text"><strong>GST:</strong> <?php echo $row['gst']; ?>%</p>
                            <p class="card-text"><strong>Discount:</strong> <?php echo $row['discount']; ?>%</p>
                            <p class="card-text"><strong>Facilities:</strong> <?php echo $row['facilities']; ?></p>
                        </div>
                        <div class="card-footer text-center">
                            <a href="update.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                            <a href="delete.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm">Delete</a>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz4fnFO9gybB3vsIO+PpPp4M6e9a6X/21cKH95Xg9U7T2RfwXjj3gR+Hax" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-ZvpUoO/+PpE0h7c3vc0Xj5T1f0o8LwYv6q9Pbxl1/NFfc5n8g8L5y+2xuZ2fNNh0b" crossorigin="anonymous"></script>
  </body>
</html>
