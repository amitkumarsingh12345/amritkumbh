
         <!-- Room Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                    <h6 class="section-title text-center text-primary text-uppercase">Our Rooms</h6>
                    <h1 class="mb-5">Explore Our <span class="text-primary text-uppercase">Rooms</span></h1>
                </div>
                <div class="row g-4">
                    
          <?php
                    include 'admin/connection.php';

$sql = "SELECT * FROM room";
$result = $conn->query($sql);
$i = 0;

                    while ($row = $result->fetch_assoc()) { 
                      $i = $i+1;
                    ?>
                    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="room-item shadow rounded overflow-hidden">
                            <div class="position-relative">
                                <img class="img-fluid" src="admin/<?php echo $row['profile_image']; ?>" alt="">
                                <small
                                    class="position-absolute start-0 top-100 translate-middle-y bg-primary text-white rounded py-1 px-3 ms-4">&#8377; <?php echo $row['price']; ?> + <?php echo $row['gst']; ?> GST
</small>

                            </div>
                            <div class="p-4 mt-2">
                                <div class="d-flex justify-content-between mb-3">
                                    <h5 class="mb-0"><?php echo $row['name']; ?></h5>
                                    <div class="ps-2">
                                        <small class="fa fa-star text-primary"></small>
                                        <small class="fa fa-star text-primary"></small>
                                        <small class="fa fa-star text-primary"></small>
                                        <small class="fa fa-star text-primary"></small>
                                        <small class="fa fa-star text-primary"></small>
                                    </div>
                                </div>
                                <!--<i class="fa fa-bed text-primary me-2">-->
                                <div class="d-flex mb-3">
                                    <small class="border-end me-3 pe-3"><span class="bg-primary text-white rounded px-1"><?php echo $row['discount']; ?> Off</span>
                                        </small>
                                    <small class="border-end me-3 pe-3"><i class="fa fa-bath text-primary me-2"></i><?php echo $row['size']; ?></small>
                                    <small><i class="fa fa-wifi text-primary me-2"></i>Wifi</small>
                                </div>
                                <p class="text-body mb-3"><?php echo $row['facilities']; ?></p>
                                <div class="d-flex justify-content-between">
                                    <a class="btn btn-sm btn-primary rounded py-2 px-4" href="view.php?id=<?php echo $row['id']; ?>">View Detail</a>
                                    <a class="btn btn-sm btn-dark rounded py-2 px-4" href="booking.php?id=<?php echo $row['id']; ?>">Book Now</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php } ?>
                    
                    
                    <!--<div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">-->
                    <!--    <div class="room-item shadow rounded overflow-hidden">-->
                    <!--        <div class="position-relative">-->
                    <!--            <img class="img-fluid" src="img/room-2.jpg" alt="">-->
                    <!--            <small-->
                    <!--                class="position-absolute start-0 top-100 translate-middle-y bg-primary text-white rounded py-1 px-3 ms-4">10999 + 18%GST &#8377;-->
                    <!--            </small>-->
                    <!--        </div>-->
                    <!--        <div class="p-4 mt-2">-->
                    <!--            <div class="d-flex justify-content-between mb-3">-->
                    <!--                <h5 class="mb-0">Super Delux</h5>-->
                    <!--                <div class="ps-2">-->
                    <!--                    <small class="fa fa-star text-primary"></small>-->
                    <!--                    <small class="fa fa-star text-primary"></small>-->
                    <!--                    <small class="fa fa-star text-primary"></small>-->
                    <!--                    <small class="fa fa-star text-primary"></small>-->
                    <!--                    <small class="fa fa-star text-primary"></small>-->
                    <!--                </div>-->
                    <!--            </div>-->
                    <!--            <div class="d-flex mb-3">-->
                    <!--                <small class="border-end me-3 pe-3"><i class="fa fa-bed text-primary me-2"></i>3-->
                    <!--                    Bed</small>-->
                    <!--                <small class="border-end me-3 pe-3"><i class="fa fa-bath text-primary me-2"></i>-->
                    <!--                    24*12</small>-->
                    <!--                <small><i class="fa fa-wifi text-primary me-2"></i>Wifi</small>-->
                    <!--            </div>-->
                    <!--            <p class="text-body mb-3">Charge For Normal Days - 15000 with meal and get with Washroom, Gizer, Wifi, CCTV, News Paper</p>-->
                    <!--            <div class="d-flex justify-content-between">-->
                    <!--                <a class="btn btn-sm btn-primary rounded py-2 px-4" href="">View Detail</a>-->
                    <!--                <a class="btn btn-sm btn-dark rounded py-2 px-4" href="">Book Now</a>-->
                    <!--            </div>-->
                    <!--        </div>-->
                    <!--    </div>-->
                    <!--</div>-->
                    <!--<div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.6s">-->
                    <!--    <div class="room-item shadow rounded overflow-hidden">-->
                    <!--        <div class="position-relative">-->
                    <!--            <img class="img-fluid" src="img/room-3.jpg" alt="">-->
                    <!--            <small-->
                    <!--                class="position-absolute start-0 top-100 translate-middle-y bg-primary text-white rounded py-1 px-3 ms-4">18000 &#8377;</small>-->
                    <!--        </div>-->
                    <!--        <div class="p-4 mt-2">-->
                    <!--            <div class="d-flex justify-content-between mb-3">-->
                    <!--                <h5 class="mb-0">Super Deluxe <br/>(Shahi Snan)</h5>-->
                    <!--                <div class="ps-2">-->
                    <!--                    <small class="fa fa-star text-primary"></small>-->
                    <!--                    <small class="fa fa-star text-primary"></small>-->
                    <!--                    <small class="fa fa-star text-primary"></small>-->
                    <!--                    <small class="fa fa-star text-primary"></small>-->
                    <!--                    <small class="fa fa-star text-primary"></small>-->
                    <!--                </div>-->
                    <!--            </div>-->
                    <!--            <div class="d-flex mb-3">-->
                    <!--                <small class="border-end me-3 pe-3"><i class="fa fa-bed text-primary me-2"></i>3-->
                    <!--                    Bed</small>-->
                    <!--                <small class="border-end me-3 pe-3"><i class="fa fa-bath text-primary me-2"></i>-->
                    <!--                    12*16</small>-->
                    <!--                <small><i class="fa fa-wifi text-primary me-2"></i>Wifi</small>-->
                    <!--            </div>-->
                    <!--            <p class="text-body mb-3">Charge For Normal Days - 15000 with meal and get with Washroom, Gizer, Wifi, CCTV, News Paper</p>-->
                    <!--            <div class="d-flex justify-content-between">-->
                    <!--                <a class="btn btn-sm btn-primary rounded py-2 px-4" href="">View Detail</a>-->
                    <!--                <a class="btn btn-sm btn-dark rounded py-2 px-4" href="">Book Now</a>-->
                    <!--            </div>-->
                    <!--        </div>-->
                    <!--    </div>-->
                    <!--</div>-->
                </div>
            </div>
        </div>
        <!-- Room End -->