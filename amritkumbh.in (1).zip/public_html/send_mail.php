<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate input
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $phone = htmlspecialchars($_POST['phone']);
    $start = htmlspecialchars($_POST['start']);
    $end = htmlspecialchars($_POST['end']);
    $subject = htmlspecialchars($_POST['subject']);
    $message = htmlspecialchars($_POST['message']);

    // Define email details
    $to = "amritkumbh8@gmail.com"; 
    $subject_line = "Contact Form Submission: " . $subject;

    // Compose email body
    $email_body = "You have received a new message from your website contact form.\n\n";
    $email_body .= "Name: " . $name . "\n";
    $email_body .= "Email: " . $email . "\n";
    $email_body .= "Phone: " . $phone . "\n";
    $email_body .= "Start Date & Time: " . $start . "\n";
    $email_body .= "End Date & Time: " . $end . "\n";
    $email_body .= "Subject: " . $subject . "\n";
    $email_body .= "Message: " . $message . "\n";

    // Set email headers
    $headers = "From: " . $email . "\r\n";
    $headers .= "Reply-To: " . $email . "\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

    // Database credentials
   include 'admin/connection.php';

    // Create MySQL connection
    $conn = new mysqli($servername, $username, $password, $db_name);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare SQL statement for inserting data
    $stmt = $conn->prepare("INSERT INTO customer (name, email, start, end, subject, phone, message) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $name, $email, $start, $end, $subject, $phone, $message); // 'sssssss' because all fields are strings

    // Execute the query
    if ($stmt->execute()) {
        echo "New record created successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();

    // Send the email
    if (mail($to, $subject_line, $email_body, $headers)) {
        // Set a cookie to indicate successful submission
        setcookie("electronic", true);
        echo "<p>Thank you for contacting us, " . $name . ". Your message has been sent successfully!</p>";
    } else {
        echo "<p>Sorry, there was an issue sending your message. Please try again later.</p>";
    }

    // Redirect to index.php after a successful submission
    header("Location: booking.php");
    exit();
}
?>
